import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActividadesComponent } from './Actividad/actividades/actividades.component';
import { CrearActComponent } from './Actividad/crear-act/crear-act.component';
import { EditarActComponent } from './Actividad/editar-act/editar-act.component';
import { CrearUsuarioComponent } from './Usuario/crear-usuario/crear-usuario.component';
import { UsuarioComponent } from './Usuario/usuario/usuario.component';

const routes: Routes = [
  { path: 'crear-usuario', component: CrearUsuarioComponent },
  { path: 'usuario', component: UsuarioComponent },
  { path: 'actividades', component: ActividadesComponent },
  { path: 'actividad', component: CrearActComponent },
  { path: 'editar-act/:id', component: EditarActComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
