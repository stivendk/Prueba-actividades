import { Usuario } from './Usuario';

export class Actividad{
    id:number;
    titulo: String;
    descripcion: String;
    horaInicio: Date;
    horaFinal: Date;
    estado: String;
    idUsuario: Usuario;
}