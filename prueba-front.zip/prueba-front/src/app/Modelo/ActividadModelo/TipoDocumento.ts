export class TipoDocumento{
    id: number;
    tipoDocumento: String;
}