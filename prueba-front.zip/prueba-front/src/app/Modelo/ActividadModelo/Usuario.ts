import { TipoDocumento } from './TipoDocumento';

export class Usuario{
    id: number;
    nDocumento: number;
    primerNombre: String;
    segundoNombre: String;
    primerApellido: String;
    segundoApellido: String;
    edad: number;
    tipoDocumento: TipoDocumento;

}