import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditarActComponent } from './editar-act.component';

describe('EditarActComponent', () => {
  let component: EditarActComponent;
  let fixture: ComponentFixture<EditarActComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditarActComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditarActComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
