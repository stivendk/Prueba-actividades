import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Actividad } from 'src/app/Modelo/ActividadModelo/Actividad';
import { Usuario } from 'src/app/Modelo/ActividadModelo/Usuario';
import { ActividadServicioService } from 'src/app/Servicio/actividad-servicio.service';
import { UsuarioServicioService } from 'src/app/Servicio/usuario-servicio.service';

enum Estado {
  PorHacer = 'Por Hacer',
  Hecho = 'Hecho'
}

@Component({
  selector: 'app-editar-act',
  templateUrl: './editar-act.component.html',
  styleUrls: ['./editar-act.component.css']
})
export class EditarActComponent implements OnInit {

  actividad: Actividad = new Actividad();
  usuarios: Usuario[];
  id: number;
  enumEstado = Estado;

  constructor(private servicio: ActividadServicioService, private servicioUsuario: UsuarioServicioService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.servicioUsuario.getUsuarios().subscribe(data => {
        this.usuarios = data;
      })

      if (params && Object.keys(params).length && params.id) {
        this.servicio.getActividadById(params.id).subscribe(data => {
          this.actividad = data;
        });
      }
    })
  }

  onSubmit() {
    this.route.params.subscribe(params => {
      this.servicio.actividadUpd(params.id, this.actividad).subscribe(data => {
        this.verTareas();
      }
        , error => console.log(error));
    });

    /*this.servicio.actividadUpd(this.id, this.actividad).subscribe(data => {
      this.verTareas();
    });*/
  }

  verTareas() {
    this.router.navigate(['/actividades']);
  }

}
