import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Actividad } from 'src/app/Modelo/ActividadModelo/Actividad';
import { ActividadServicioService } from 'src/app/Servicio/actividad-servicio.service';

@Component({
  selector: 'app-actividades',
  templateUrl: './actividades.component.html',
  styleUrls: ['./actividades.component.css']
})
export class ActividadesComponent implements OnInit {

  actividades:Actividad[];
  enumEstado = ["Hecho", "Por Hacer"];
  constructor(private service:ActividadServicioService, private router:Router) { }

  ngOnInit(): void {
    this.service.getActividad().subscribe(data=>{
      this.actividades=data;
    })
  }

  SeleccionarActividad(actividad: Actividad){
    this.router.navigate([`/editar-act/${actividad.id}`]);
  }

  eliminarAct(actividad: Actividad){
    this.service.eliminarActividad(actividad.id).subscribe( data => {
      console.log(data);
      window.location.reload();
    })
  }
}
