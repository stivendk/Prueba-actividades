import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Actividad } from 'src/app/Modelo/ActividadModelo/Actividad';
import { Usuario } from 'src/app/Modelo/ActividadModelo/Usuario';
import { ActividadServicioService } from 'src/app/Servicio/actividad-servicio.service';
import { UsuarioServicioService } from 'src/app/Servicio/usuario-servicio.service';

@Component({
  selector: 'app-crear-act',
  templateUrl: './crear-act.component.html',
  styleUrls: ['./crear-act.component.css']
})
export class CrearActComponent implements OnInit {

  actividad: Actividad = new Actividad();
  usuarios: Usuario[];
  id: number;

  constructor(private servicio: ActividadServicioService, private servicioUsuario: UsuarioServicioService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.servicioUsuario.getUsuarios().subscribe(data => {
      this.usuarios = data;
    })

  }

  guardarActividad() {
    this.servicio.crearActividad(this.actividad).subscribe(data => {
      console.log(data);
      this.verTareas();
    },
      error => console.log(error));
  }

  verTareas() {
    this.router.navigate(['/actividades']);
  }

  onSubmit() {
    console.log(this.actividad);
    this.guardarActividad();
  }
}
