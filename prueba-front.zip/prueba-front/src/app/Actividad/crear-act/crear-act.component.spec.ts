import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearActComponent } from './crear-act.component';

describe('CrearActComponent', () => {
  let component: CrearActComponent;
  let fixture: ComponentFixture<CrearActComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrearActComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearActComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
