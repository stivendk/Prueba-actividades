import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from 'src/app/Modelo/ActividadModelo/Usuario';
import { UsuarioServicioService } from 'src/app/Servicio/usuario-servicio.service';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {

  usuarios:Usuario[];
  constructor(private servicio:UsuarioServicioService, private router: Router) { }

  ngOnInit(): void {
    this.servicio.getUsuarios().subscribe(data=>{
      this.usuarios=data;
    })
  }

}
