import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TipoDocumento } from 'src/app/Modelo/ActividadModelo/TipoDocumento';
import { Usuario } from 'src/app/Modelo/ActividadModelo/Usuario';
import { TipoDocumentoService } from 'src/app/Servicio/tipo-documento.service';
import { UsuarioServicioService } from 'src/app/Servicio/usuario-servicio.service';

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent implements OnInit {

  usuario: Usuario = new Usuario();
  tipoDocuments: TipoDocumento[];
  constructor(private servicioUsuario: UsuarioServicioService, private servicioTipoDocumento: TipoDocumentoService, private router: Router) { } 

  ngOnInit(): void {
    this.servicioTipoDocumento.getTipoDocumento().subscribe(data=>{
      this.tipoDocuments = data;
    })
  }

  guardarUsuario(){
    this.servicioUsuario.crearUsuario(this.usuario).subscribe( data =>{
      console.log(data);
      this.verTareas();
    },
    error => console.log(error));
  }

  verTareas(){
    this.router.navigate(['/actividades']);
  }

  onSubmit(){    
    console.log(this.usuario);
    this.guardarUsuario();
  }
}
