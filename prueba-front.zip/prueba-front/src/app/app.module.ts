import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsuarioComponent } from './Usuario/usuario/usuario.component';
import { CrearUsuarioComponent } from './Usuario/crear-usuario/crear-usuario.component';
import { ActividadesComponent } from './Actividad/actividades/actividades.component';
import { CrearActComponent } from './Actividad/crear-act/crear-act.component';
import { EditarActComponent } from './Actividad/editar-act/editar-act.component';
import {FormsModule} from '@angular/forms';
import { ActividadServicioService } from './Servicio/actividad-servicio.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    UsuarioComponent,
    CrearUsuarioComponent,
    ActividadesComponent,
    CrearActComponent,
    EditarActComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ActividadServicioService],
  bootstrap: [AppComponent]
})
export class AppModule { }
