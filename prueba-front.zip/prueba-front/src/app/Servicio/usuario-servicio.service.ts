import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Usuario } from '../Modelo/ActividadModelo/Usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioServicioService {
 
  baseUrl= 'http://localhost:8080/api/v1/usuarios';

  constructor(private http:HttpClient) {}

  getUsuarios(): Observable<Usuario[]>{
    return this.http.get<Usuario[]>(this.baseUrl);
  }

  crearUsuario(usuario: Usuario): Observable<Object>{
    return this.http.post(`${this.baseUrl}`, usuario);
  }

}
