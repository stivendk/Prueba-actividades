import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import { Actividad } from '../Modelo/ActividadModelo/Actividad';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ActividadServicioService {

  baseUrl= 'http://localhost:8080/api/v1/actividades';

  constructor(private http:HttpClient) { }

  getActividad(): Observable<Actividad[]>{
    return this.http.get<Actividad[]>(this.baseUrl);
  }

  getActividadById(id:Number): Observable<Actividad>{
    return this.http.get<Actividad>(`${this.baseUrl}/${id}`);
  }

  crearActividad(actividad: Actividad): Observable<Object>{
    return this.http.post(`${this.baseUrl}`, actividad);
  }

  actividadUpd(id: number, actividad: Actividad): Observable<Object>{
    return this.http.put(`${this.baseUrl}/${id}`, actividad);
  }

  eliminarActividad(id: number): Observable<Object>{
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
