import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TipoDocumento } from '../Modelo/ActividadModelo/TipoDocumento';

@Injectable({
  providedIn: 'root'
})
export class TipoDocumentoService {
 
  baseUrl= 'http://localhost:8080/api/v1/tipoDocumentos';

  constructor(private http:HttpClient) { }

  getTipoDocumento(): Observable<TipoDocumento[]>{
    return this.http.get<TipoDocumento[]>(this.baseUrl);
  }
}
