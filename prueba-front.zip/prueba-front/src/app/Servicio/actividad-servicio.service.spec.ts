import { TestBed } from '@angular/core/testing';

import { ActividadServicioService } from './actividad-servicio.service';

describe('ActividadServicioService', () => {
  let service: ActividadServicioService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ActividadServicioService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
